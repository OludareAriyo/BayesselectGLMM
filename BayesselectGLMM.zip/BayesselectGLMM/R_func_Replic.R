#######################   mDIC_func.R       ################################
#                                                                             #  
# R function to compute mDIC based on the proposed methods. Based on the      # 
# JAGS file "file_model", the function creates a new JAGS file Replic.txt     #
# where the replicated latent variables are generated. With this file,        #
# the parent nodes (variables with ~ that are not the response or latent      #
# variables) are fixed to take the sampled values in "mc_sam". For this,      #
# all parent nodes must have been saved in "mc_sam". The parameters of the    #
# function are explained below. The first block of parameters is necessary    #
# to run the replication method. The second block is for approximations of    #
# Section 3.2. The third block 3 is for specific cases where the JAGS file    #
# to run replication needs to be created by hand as in Toenail. The last      #
# block is for importance sampling                                            #
###############################################################################

### Block 1
#nL: Number of replications per MCMC iteration
#nM: Number of replications for plug-in deviance
#resp (string): Name of response in JAGS file
#ntot (integer): Total number of data points in data
#clust (dim: nobs x 1): vector with id's of clusters
#latent (string): Name of latent variables in JAGS file
#nparal (integer): Number of cores to run parallel replication for average deviance
#file_model (string): File with JAGS model
#data_list (list): Data list that was used to sample MCMC for model 'file_model' in JAGS
#mc_sam: MCMC object, all the sampled parent nodes must be saved, i.e., all the terms with ~ in 
#JAGS file which are not latent variables or response
#alliter: If FALSE a maximum of 3000 iterations in the MCMC sample will be used

### Block 2
#manual: If it is 0 the function creates the JAGS file for replication, if it is 1 then the person creates it
#paramj: If manual=1 then paramj is the vector with names in MCMC of parent nodes given through params[]
#filerep: If manual=1 then the user can specify the file he created for replication in JAGS

# nM=10000; nL=10000; clust=clust; file_model="JAGS_NegBin.txt"; data_list=data_jags;
# mc_sam=mcmc2_s; resp="Y"; ntot=ntot; latent="lamu"; alliter=FALSE;
# manual=0; filerep="Replic.txt"
# mu_lat=mu_lam; sd_lat=sd_lam; 

mDIC_IS <- function(nL, nM, resp, ntot, clust=0, latent, nparal,
                      file_model, data_list, mc_sam, alliter=FALSE,
                      manual=0, paramj=NULL, filerep="Replic.txt",
                      nburn, nthin)
{
  
  if(length(clust)>1)
  {
    clustl <- split(seq(ntot), clust) #cluster ID list
    nclus <- length(clustl)
  }else{
    nclus <- ntot
  }
  
  names_mcmc <- dimnames(mc_sam[[1]])[[2]] #Names of parameters in MCMC
  
  if(manual==0) # Create JAGS file for replication
  {
    param_file <- write_rep_file(file_model, latent, resp, names_mcmc)
    param_s <- param_file$param_s
  }else{ #If for some reason the JAGS file for replication needs to be created manually
    param_s <- paramj
  }
  
  param_out <- param_s[!param_s%in%names_mcmc] #Parent nodes missing in MCMC
  if(length(param_out)>0)
    print(paste("Please save in MCMC also",param_out))
  
  sample_par <- as.matrix(mc_sam[,param_s]) #Sample of parameters Psi
  nK <- nrow(sample_par) #Number of MCMC iterations
  
  if(nK>3000 & alliter==FALSE)
  {
    print(paste("Only 3000 out of the",nK,"total iterations will be used, see parameter alliter in function"))
    sample_par <- sample_par[round(seq(from=1,to=nK,length.out=3000)),]
    nK <- nrow(sample_par)
  }
  
  ######
  ###### IS for plug-in deviance
  ######
  
  mean_par <- colMeans(sample_par) #Posterior mean of Psi
  
  ### Data for replication in JAGS
  postPar <- summary(mc_sam[,param_s])
  data_resam <- c(data_list, params = list(postPar$statistics[,1]))
  
  ### Samble given Psi_bar
  mcmc_resam <- jags.model(file="File_IS.txt", data=data_resam, n.chains=3, quiet=TRUE)
  update(mcmc_resam, n.iter=nburn, progress.bar=NULL)
  mcmc_resam_s <- coda.samples(mcmc_resam, latent, n.iter=niter, thin=nthin, progress.bar=NULL)
  
  ### Posterior mean and SD of latent variables
  mu_lat <- colMeans(as.matrix((mcmc_resam_s[,paste0(latent, "[", 1:max(clust), "]")])))
  sd_lat <- apply(as.matrix((mcmc_resam_s[,paste0(latent, "[", 1:max(clust),"]")])), 2, sd)
  
  ### Run importance sampling based on normal distribution
  dataj <- c(data_resam, list(mu_lat=mu_lat,sd_lat=sd_lat))
  mcmc_p <- jags.model(file=filerep, data=dataj, n.chains=1, quiet=TRUE)
  mcmc_p <- coda.samples(mcmc_p, c("like",latent,"p_lat","q_lat"), n.iter=nM, thin=1, progress.bar=NULL)
  names_mcmc <- dimnames(mcmc_p[[1]])[[2]]
  lat_rep <- as.matrix(mcmc_p[,grep(paste0(latent,"\\["),names_mcmc)])
  px <- as.matrix(mcmc_p[,grep("p_lat\\[",names_mcmc)])
  qx <- as.matrix(mcmc_p[,grep("q_lat\\[",names_mcmc)])
  mcmc_p <- mcmc_p[,grep("like\\[",names_mcmc)]
  
  
  lp_yi_p <- t(log(as.matrix(mcmc_p))); rm(mcmc_p)
  if(length(clust)>1)
  {
    lp_yi_p <- sapply(clustl, function(a) colSums(lp_yi_p[a, ,drop=FALSE]))
    lp_yi_p <- lp_yi_p + log(px) - log(qx)
  }else{
    lp_yi_p <- t(lp_yi_p)
  }
  
  standlog <- 700-apply(lp_yi_p, 2, max) #Numerical trick so exp() is not zero when lp_yi_p is very small
  standlog <- t(matrix(standlog))
  p_yi_p <- colMeans(exp(lp_yi_p + matrix(1,nrow=nM,ncol=1)%*%standlog))
  logL_p <- log(p_yi_p) - standlog
  
  #Estimated variance for plug-in deviance
  var_plug <- 4*(colMeans(exp(2*lp_yi_p-2*matrix(rep(logL_p,nM),nrow=nM,byrow=TRUE)))-1)/nM
  var_plug <- sum(var_plug)
  sd_plug <- sqrt(var_plug)
  
  print("The plug-in deviance has been calculated")
  
  if(sd_plug>0.5)
    print(paste("The standard error of the plug-in deviance is",sd_plug,
                ", you may want to stop the computation and increase the value of nM"))
  
  ######
  ###### Average deviance: accross iterations 1,...,nK
  ######
  
  print("Computing the mean deviance")
  
  cl <-makeCluster(nparal); registerDoSNOW(cl) #Create multi-cluster
  logLk <- foreach(k=1:nK, .packages='rjags',  .combine='rbind') %dopar% 
    {
      if((k %% 100)==0)
        print(paste(k, "MCMC iterations out of", nK))
      ### Data for replication in JAGS
      data_resam <- c(data_list, params = list(sample_par[k,]))
      
      ### Sample given Psi_k
      mcmc_resam <- jags.model(file="File_IS.txt", data=data_resam, n.chains=3, quiet=TRUE)
      update(mcmc_resam, n.iter=nburn, progress.bar=NULL)
      mcmc_resam_s <- coda.samples(mcmc_resam, latent, n.iter=nburn, thin=nthin, progress.bar=NULL)
      
      ### Posterior mean and SD of latent variables
      mu_lat <- colMeans(as.matrix((mcmc_resam_s[,paste0(latent, "[", 1:max(clust), "]")])))
      sd_lat <- apply(as.matrix((mcmc_resam_s[,paste0(latent, "[", 1:max(clust),"]")])), 2, sd)
      
      ### Run importance sampling based on normal distribution
      dataj <- c(data_resam, list(mu_lat=mu_lat,sd_lat=sd_lat))
      
      mcmc_k <- jags.model(file=filerep, data=dataj, n.chains=1, quiet=TRUE)
      mcmc_k <- coda.samples(mcmc_k, c("like",latent,"p_lat","q_lat"), n.iter=nL, thin=1, progress.bar=NULL)
      
      ##################################
      
      names_mcmc <- dimnames(mcmc_k[[1]])[[2]]
      lat_rep <- as.matrix(mcmc_k[,grep(paste0(latent,"\\["),names_mcmc)])
      px <- as.matrix(mcmc_k[,grep("p_lat\\[",names_mcmc)])
      qx <- as.matrix(mcmc_k[,grep("q_lat\\[",names_mcmc)])
      mcmc_k <- mcmc_k[,grep("like\\[",names_mcmc)]
      
      
      lp_yi_k <- t(log(as.matrix(mcmc_k))); rm(mcmc_k)
      if(length(clust)>1)
      {
        lp_yi_k <- sapply(clustl, function(a) colSums(lp_yi_k[a, ,drop=FALSE]))
        lp_yi_k <- lp_yi_k + log(px) - log(qx)
      }else{
        lp_yi_p <- t(lp_yi_p)
      }
      
      standlog <- 700-apply(lp_yi_k, 2, max) #Numerical trick so exp() is not zero when lp_yi_p is very small
      standlog <- t(matrix(standlog))
      p_yi_k <- exp(log(colMeans(exp(lp_yi_k + matrix(1,nrow=nL,ncol=1)%*%standlog))) - standlog)

      var_ave <- 1/nL*(colMeans(exp(2*lp_yi_k-2*matrix(rep(log(p_yi_k),nL),nrow=nL,byrow=TRUE)))-1)
      
      c(log(p_yi_k), sum(var_ave))
    }
  stopCluster(cl)
  
  var_ave <- sum(4*logLk[,ncol(logLk)])/nK^2
  logLk <- colMeans(logLk[,1:(ncol(logLk)-1)]) #Average log-Like. accross iterations
  
  return(list(logLk=logLk, logL_p=logL_p, sd_ave=sqrt(var_ave), sd_plug=sd_plug,
              sd_mDIC=sqrt(4*var_ave+var_plug)))
}

#### Function that writes JAGS file for replication, it returns the parent nodes in model
write_rep_file <- function(file_model, latent, resp, names_mcmc)
{                      
  codej <- readLines(file_model)
  for(ii in 1:length(codej))
  {
    if(length(grep("for\\(",gsub("( |\t)","",codej[ii])))==0)
      codej[ii] <- gsub("( |\t)","", codej[ii])
  }
  
  parai <- grep("~", codej)
  parai <- parai[!parai%in%grep(paste0("(^| |\t)(",latent,"|",resp,")(\\[)"), codej)] #Index of nodes
  
  paramj <- codej[parai] #Lines with parameters Psi
  pospar <- regexpr('~', paramj)[1:length(paramj)] #Position in line where parameters are
  paramj <- substr(paramj, 1, pospar-1) #Parameters already sampled
  
  ### Set in code parameters equal to standard named parameters p1,p2,..
  count_pars <- 0
  param_s <- NULL
  for(ii in 1:length(parai))
  {
    posii <- regexpr('~', codej[parai[ii]])[1]
    if(length(grep("dwish",codej[parai[ii]]))>0) #When Wishart, the parameter is a matrix
    {
      if(length(grep("\\[",paramj[ii]))>0)
        paramj[ii] <- substr(paramj[ii], 1, regexpr("\\[",paramj[ii])[1]-1)
      var_pars <- grep(paste0("(^",paramj[ii],")(\\[|~)"), names_mcmc, value=TRUE)
      until_par <- length(var_pars)
      codej[parai[ii]] <- paste0(var_pars, "<- params[", (count_pars+1):(count_pars+until_par),"]", collapse=";")
      count_pars <- count_pars + until_par
      param_s <- c(param_s, var_pars)
    }else{
      if(length(grep("\\[",codej[parai[ii]]))>0) #If the parameter is accompanied by []
      {
        paramj[ii] <- substr(paramj[ii], 1, regexpr("\\[",paramj[ii])[1]-1)
        index_par <- substr(codej[parai[ii]], regexpr("\\[", codej[parai[ii]])[1]+1, regexpr("\\]", codej[parai[ii]])[1]-1)
        if(length(grep(",",index_par))>0)
          print(paste("Please do not include parameter",paramj[ii],"in array, the function needs vectorized parameters"))
        if(grep("[a-zA-Z]+",index_par)>0) #If the index of the parameter has letters then it is a loop
        {
          codej[parai[ii]] <- paste0(substr(codej[parai[ii]], 1, posii-1), "<- params[", index_par,"+",count_pars,"]")
          until_par <- length(grep(paste0("^",paramj[ii],"\\["), names_mcmc))
          param_s <- c(param_s, paste0(paramj[ii],"[",1:until_par,"]"))
          count_pars <- count_pars + until_par
        }else{  #If the index of the parameter has no letters then it is just one component of the parameter vector
          codej[parai[ii]] <- paste0(substr(codej[parai[ii]], 1, posii-1), "<- params[", count_pars+1,"]")
          param_s <- c(param_s, paramj[ii])
          count_pars <- count_pars + 1
        }
      }else{ #The parameter is univariate
        codej[parai[ii]] <- paste0(substr(codej[parai[ii]], 1, posii-1), "<- params[", count_pars+1,"]")
        param_s <- c(param_s, paramj[ii])
        count_pars <- count_pars + 1
      }
    }
  }
  
  ### How the response appears indexed in JAGS
  line_resp <- grep(paste0("(^| |\t)",resp,"(\\[)"), codej)
  posy <- regexpr('~', codej[line_resp])[1]
  resp_ind <- substr(codej[line_resp], 1, posy-1)
  
  ### Distribution of response
  posy <- regexpr("~",codej[line_resp])[1]
  distry <- substr(codej[line_resp], posy+1, posy+regexpr("\\(",substr(codej[line_resp],posy,1000))[1]-2)
  
  if(distry%in%c("dbern","dbinom"))
    print("The distribution",distry,"is not defined to compute likelihood in JAGS")
  
  #Create code for importance sampling
  cat(codej, file="File_IS.txt", sep="\n") #Create JAGS file for replication
  
  ### Compute likelihood for observations
  codej[line_resp] <- gsub(paste0(distry,"\\("), paste0(distry,"(",resp_ind,","), codej[line_resp])
  codej[line_resp] <- sub(resp, "like", codej[line_resp])
  codej[line_resp] <- gsub("~", "<-", codej[line_resp])
  index_resp <- substr(resp_ind, regexpr("\\[", resp_ind)[1], regexpr("\\]", resp_ind)[1])
  

    line_lat <- grep(paste0("(^| |\t)",latent,"(\\[)"), codej)
    index_lat <- substr(codej[line_lat], regexpr("\\[", codej[line_lat])[1], regexpr("\\]", codej[line_lat])[1])
    poslat <- regexpr('~', codej[line_lat])[1]
    lat_ind <- gsub("  *", "", substr(codej[line_lat], 1, poslat-1))
    lat_ind <- gsub("\t", "", lat_ind)
    
    distr_lat <- substr(codej[line_lat], regexpr("~",codej[line_lat])[1]+1, regexpr("\\(",codej[line_lat])[1]-1)
    distr_lat <- gsub("  *", "", distr_lat); distr_lat <- gsub("\t", "", distr_lat)
    
    samlat_l <- paste0(lat_ind, " ~ dnorm(mu_lat", index_lat, ",sd_lat", index_lat,")")
    if(distr_lat%in%c("dlnorm","dgamma"))
      samlat_l <- paste0(samlat_l, "I(0, )")
    
    samlat_l <- paste0(samlat_l, "\n p_lat", index_lat, " <- ", distr_lat, "(", lat_ind, ",", 
                       substr(codej[line_lat], regexpr("\\(",codej[line_lat])[1]+1, regexpr("\\)",codej[line_lat])[1]-1),")")
    samlat_l <- paste0(samlat_l, "\n q_lat", index_lat, " <- dnorm(", lat_ind, ",mu_lat", index_lat, ",sd_lat", index_lat,")")
    
    if(distr_lat%in%c("dlnorm","dgamma"))
      samlat_l <- paste0(samlat_l, "/(1-pnorm(0, mu_lat[i], sd_lat[i]))")
    
    codej[line_lat] <- samlat_l

  
  cat(codej, file="Replic.txt", sep="\n") #Create JAGS file for replication
  
  return(list(param_s=param_s))
}
