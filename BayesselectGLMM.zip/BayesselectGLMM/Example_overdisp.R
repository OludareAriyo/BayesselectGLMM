
library(rjags)
library(doSNOW)  # To compute mDIC
library(foreach) # in parallel
library(dclone)  #

### Working root folder
setwd("c:\\Users\\Oludare Ariyo\\Desktop\\GLMM")

### Read function with mDIC
source("mDIC_IS_func.R")

### Number of available cores for parallel computing
(ncores <- detectCores())

##########
########## Generating data
##########

nclus <- 25 #Number of clusters
nobse <- 25 #Number of observations in each cluster

### Parameters to generate PLN
mu <- exp(1.5)
gam <- 1.5

ntot <- nobse*nclus #Total sample size
clust <- sort(rep(1:nclus,nobse)) #cluster ID

set.seed(3333)
lamc <- rlnorm(n=nclus, meanlog=(log(mu)-1*gam^2/2), sdlog=gam)

set.seed(3333)
yresp <- rpois(ntot, lamc[clust])

##########
########## Information for jags
##########

nburn <- 100   #Burn-in period
niter <- 300  #Number of iterations after burn-in
nthin <- 10     #Thinning factor

data_jags <- list(N=ntot, clust=clust, 
                  nu=nclus, Y=yresp)

inits_jags <- function(){ list(lamu=rep(1,nclus)) }

##########
########## PLN model
##########

mcmc1 <- jags.model(file="JAGS_PLN.txt", 
                    data=data_jags, 
                    n.chains=3, 
                    inits=inits_jags)



update(mcmc1, n.iter=nburn)
mcmc1_s <- coda.samples(mcmc1, c("lmu","sigma","lamu"),
                        n.iter=niter, 
                        thin=nthin)


#### mDIC
time_i <- proc.time()
PLN_mDIC <- mDIC_IS(nM=1000, nL=100, clust=clust, 
                    file_model="JAGS_PLN.txt", 
                    data_list=data_jags,
                    mc_sam=mcmc1_s, resp="Y", 
                    ntot=ntot, latent="lamu",
                    nparal=ncores, 
                    nburn = nburn, 
                    nthin = nthin)

time_i <- proc.time()-time_i; time_i/60 

### Average deviance
(Devk <- -2*sum(PLN_mDIC$logLk)) #2278
PLN_mDIC$sd_ave #standard error

### Plug-in deviance
(Devp <- -2*sum(PLN_mDIC$logL_p)) #2276
PLN_mDIC$sd_plug #standard error

(pD <- Devk - Devp)
(mDIC <- Devp + 2*pD) #2280
PLN_mDIC$sd_mDIC #Standard error

##########
########## PGA model
##########

mcmc2 <- jags.model(file="JAGS_NegBin.txt", 
                    data=data_jags, 
				n.chains=3, inits=inits_jags)

update(mcmc2, n.iter=nburn)
mcmc2_s <- coda.samples(mcmc2, c("r","lam","lamu"), 
                        n.iter=niter, 
                        thin=nthin)

#### mDIC
time_i <- proc.time()
PGA_mDIC <- mDIC_IS(nM=10000, nL=1000, 
                     clust=clust, 
                    file_model="JAGS_NegBin.txt", 
                    data_list=data_jags,
                      mc_sam=mcmc2_s, 
                     resp="Y",
                    ntot=ntot, 
                    latent="lamu",
                      nparal=ncores, 
                    nburn = nburn, 
                    nthin = nthin)

time_i <- proc.time()-time_i; time_i/60 #1.5 minutes

### Average deviance
(Devk <- -2*sum(PGA_mDIC$logLk)) #2284.1
PGA_mDIC$sd_ave #standard error

### Plug-in deviance
(Devp <- -2*sum(PGA_mDIC$logL_p)) #2281.6
PGA_mDIC$sd_plug #standard error

(pD <- Devk - Devp)
(mDIC <- Devp + 2*pD) #2286
PLN_mDIC$sd_mDIC #Standard error

